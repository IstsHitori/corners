import { NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import type { Team, TeamStats } from "@/lib/types"

// Ruta de API para generar predicciones con ChatGPT
export async function POST(request: Request) {
  try {
    // Obtener datos del cuerpo de la solicitud
    const { homeTeam, awayTeam, homeStats, awayStats } = await request.json()

    // Validar que se recibieron todos los datos necesarios
    if (!homeTeam || !awayTeam || !homeStats || !awayStats) {
      return NextResponse.json({ error: "Faltan datos necesarios para la predicción" }, { status: 400 })
    }

    // Crear el prompt para ChatGPT
    const prompt = createPrompt(homeTeam, awayTeam, homeStats, awayStats)

    // Llamar a la API de OpenAI
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: prompt,
      temperature: 0.7,
      maxTokens: 500,
    })

    // Procesar la respuesta
    const result = parseAIResponse(text)

    // Devolver el resultado
    return NextResponse.json(result)
  } catch (error) {
    console.error("Error en la API de predicción:", error)
    return NextResponse.json({ error: "Error al generar la predicción" }, { status: 500 })
  }
}

// Función para crear el prompt para ChatGPT
function createPrompt(homeTeam: Team, awayTeam: Team, homeStats: TeamStats, awayStats: TeamStats): string {
  return `
  Eres un experto analista de fútbol especializado en predicciones de corners (tiros de esquina) en LaLiga.
  
  Necesito una predicción del número total de corners para el siguiente partido:
  
  Equipo local: ${homeTeam.name}
  - Corners a favor por partido: ${homeStats.cornersFor}
  - Corners en contra por partido: ${homeStats.cornersAgainst}
  - Posesión promedio: ${homeStats.possession}%
  - Ataques por partido: ${homeStats.attacks}
  - Contraataques por partido: ${homeStats.counterAttacks}
  - Posición en LaLiga: ${homeStats.position}
  - Forma reciente: ${homeStats.form}
  
  Equipo visitante: ${awayTeam.name}
  - Corners a favor por partido: ${awayStats.cornersFor}
  - Corners en contra por partido: ${awayStats.cornersAgainst}
  - Posesión promedio: ${awayStats.possession}%
  - Ataques por partido: ${awayStats.attacks}
  - Contraataques por partido: ${awayStats.counterAttacks}
  - Posición en LaLiga: ${awayStats.position}
  - Forma reciente: ${awayStats.form}
  
  Estadio: Partido en el estadio del ${homeTeam.name}
  
  Proporciona tu predicción en el siguiente formato:
  1. Número total de corners esperados (un número con un decimal, por ejemplo 9.5)
  2. Una explicación detallada de tu predicción basada en el estilo de juego de ambos equipos, estadísticas y contexto
  3. Tu nivel de confianza en la predicción (un número entre 0.5 y 0.95)
  
  Responde solo con estos tres elementos, sin introducción ni conclusión adicional.
  `
}

// Función para procesar la respuesta de ChatGPT
function parseAIResponse(response: string): {
  totalCorners: number
  explanation: string
  confidence: number
} {
  try {
    // Intentar extraer el número de corners
    const cornersMatch = response.match(/(\d+\.\d+)/)
    const totalCorners = cornersMatch ? Number.parseFloat(cornersMatch[1]) : 9.0

    // Intentar extraer el nivel de confianza
    const confidenceMatch = response.match(/confianza[:\s]+(\d+\.\d+)/i) || response.match(/(\d+\.\d+)(?=[^\d]*$)/)
    const confidence = confidenceMatch ? Math.min(0.95, Math.max(0.5, Number.parseFloat(confidenceMatch[1]))) : 0.7

    // La explicación es todo el texto, limpiando números al principio y final
    let explanation = response
      .replace(/^\s*\d+\.\d+\s*/g, "") // Eliminar número al inicio
      .replace(/\s*\d+\.\d+\s*$/g, "") // Eliminar número al final
      .trim()

    // Si la explicación es demasiado larga, cortarla
    if (explanation.length > 500) {
      explanation = explanation.substring(0, 497) + "..."
    }

    return {
      totalCorners,
      explanation,
      confidence,
    }
  } catch (error) {
    console.error("Error parsing AI response:", error)
    return {
      totalCorners: 9.0,
      explanation: response || "Predicción generada con IA.",
      confidence: 0.7,
    }
  }
}
